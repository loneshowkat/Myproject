package bookingappointment;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class MySqlConnection {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		//load the driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		// establish a connection between java application with mysql database
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3305/myproject","root","Showkat@123");
		//create statement
		Statement st=con.createStatement();
		
		//taking table name dynamically
		BufferedReader br =new BufferedReader(new InputStreamReader(System.in));
		//write and execute query
		String query=("create table doctor (Dname varchar(10),Dnumber int primary key,Dpassword int)");
		st.executeUpdate(query);
		System.out.println("table create successfully");
		st.close();
		con.close();
	}

}
