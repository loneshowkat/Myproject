package bookingappointment;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.*;
import java.io.*;


public class AppointmentBooking {
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		AppointmentBooking ap=new AppointmentBooking ();
		Scanner sc=new Scanner (System.in);
		ap.dataAdd();
		boolean flag=true;
		while(flag=true)
		{
			new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
			System.out.println("  -----------------------------------------");
			System.out.println(" | Welcome  to doctor appointment          |");
			System.out.println("  -----------------------------------------");	
			System.out.println("1: Doctor");
			System.out.println("2: Patient");
			System.out.println("3: Admin ");
		    System.out.println("4: Exit");
		    int choice=sc.nextInt();
		    switch(choice)
		    {
		    case 1:
		    	ap.doctor();
		    	flag=true;
		    	break;
		    case 2:
		    	ap.patient();
		    	flag=true;
		    	break;
		    case 3:
		    	ap.Admin();
		    	flag=true;
		    	break;
		    	default:
		    		System.exit(0);
		    }
		    
		}


	}
	

	private void Admin() throws Exception{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		byte choice;
		boolean flag=true;
		
		while (flag)
		{
			new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
			System.out.println("  ----------------------- ");
			System.out.println(" |                       | ");
			System.out.println(" |     Welcome Admin     |  ");
			System.out.println(" |                       | ");
			System.out.println("  ----------------------- ");
			System.out.println("1.Doctor List, 2.Registered Patient , 3.Patients with Appointments, 4.Main menu , ");
			choice=sc.nextByte();
			switch(choice)
			{
			case 1:
				for(int i=0;i<=doctorName.size()-1;i++)
				{
					System.out.println(""+doctorName.get(i));
				}
				byte menuChoice = 0;
				System.out.println("1.Main menu, 2.Previous menu ");
				
				if (menuChoice==1)
				{
					flag=false;
				}
				else {
					break;
				}
				break;
				
			case 2:
				if(patientName.isEmpty())
				{
					System.out.println("No Registered Records Yet");
					Thread.sleep(3000);
					break;
				}
				else
				{
					for(int i=0;i<=patientName.size()-1;i++)
					{
						System.out.println("i"+patientName.get(i));
					}
					System.out.println("1.Main menu, 2.Previous menu ");
					menuChoice=sc.nextByte();
					if(menuChoice==1)
					{
						flag=false;
					}
					else
					{
						break;
					
					}
				}
				break;
			case 3:
				if(patientNameBooking.isEmpty())
				{
					System.out.println("No Applications Yet");
					Thread.sleep(3000);
					break;
				}
				else
				{
					for(int i=0;i<=patientNameBooking.size();i++)
					{
						System.out.println("i" +patientNameBooking.get(i));
					}
					System.out.println("1.Main menu, 2.Previous menu ");
					menuChoice=sc.nextByte();
					if(menuChoice==1)
					{
						flag=false;
					}
					else
					{
						break;
					}
				}
				break;
				
			case 4:
				flag=false;
				break;
				
				default:
					System.out.println("Wrong Choice");
					Thread.sleep(1000);
					flag=true;
			}
		}
		
	}

	private void patient() throws Exception {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		boolean flag=true;
		while(flag) {
			new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
			System.out.println("  -------------------------------- ");
			System.out.println(" |                                | ");
			System.out.println(" |     Welcome to patient page    | ");
			System.out.println(" |                                | ");
			System.out.println("  -------------------------------- ");
			System.out.println("");
			System.out.println("1.login");
			System.out.println("2.Registration");
			int ch=sc.nextInt();
			switch(ch) { 
			case 1:
				if (patientMobileNumber.isEmpty())
				{
					System.out.println("First register yourself then login");
					Thread.sleep(500);
					break;
				}
				else
				{
					patientLogin();
					flag=false;
				}
				break;
			case 2:
				patientRegistration();
				flag=false;
				break;
				default:
					System.out.println("You entered wrong choice enter choice again");
					flag=true;
					Thread.sleep(1000);
					break;
			
			}
			
		}

		
	}

	private void patientRegistration() throws Exception{
		// TODO Auto-generated method stub
		Scanner sc =new Scanner (System.in);
		int i=0;
		long mobileNumber;
		new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
		System.out.println("");
		System.out.println("Welcome to patint's page");
		System.out.println("");
		System.out.println("Please enter your name");
		patientName.add(sc.nextLine());
		System.out.println("Enter your age");
		patientAge.add(sc.nextInt());
		System.out.println("Please Enter your mobile number");
		mobileNumber=sc.nextLong();
		long mno;
		boolean flag=true ,flag1=true;
		
		if(patientMobileNumber.isEmpty())
		{
			patientMobileNumber.add(mobileNumber);
			System.out.println("Enter your Password");
			patientPassword.add(sc.next());
			System.out.println("Registrsation is successful");
			Thread.sleep(1000);
			flag=false;
			
		}
		else
		{
			for(i=0;i<=patientMobileNumber.size();i++)
			{
				mno=patientMobileNumber.get(i);
				
				if(mno==mobileNumber)
				{
					flag=false;
					break;
				}
			}
			if(flag==true)
			{
				patientMobileNumber.add(mobileNumber);
				System.out.println("Enter Pssword");
				patientPassword.add(sc.next());
				System.out.println("Registration is Successful");
				Thread.sleep(900);
			}
			else
			{
				System.out.println("Same mobile number is not allowed");
			}
		}
		
	}


	private void patientLogin() throws Exception  {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		boolean flag=true;
		long mobileNumber;
		byte choice;
		new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
		System.out.println("  -------------------------------- ");
		System.out.println(" |                                | ");
		System.out.println(" |           Login                |  ");
		System.out.println(" |                                | ");
		System.out.println("  -------------------------------- ");
	
		System.out.println("Enter your username(mobileNumber)");
		mobileNumber=sc.nextLong();
		System.out.println("Enter your password");
		String password=sc.next();
		boolean flag1=false;
		int j;
		for(j=0;j<=patientMobileNumber.size()-1;j++)
		{
			if((patientMobileNumber.get(j)).equals(mobileNumber)&&(patientPassword.get(j).equals(password)))
					{
				flag1=true;
				break;
					}
		}
	   if(flag1=true)
	   {
		   Thread.sleep(1000);
		   new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
			System.out.println("  -------------------------------- ");
			System.out.println(" |                                | ");
			System.out.println(" |      Book   Appointment        | ");
			System.out.println(" |                                | ");
			System.out.println("  -------------------------------- ");
			System.out.println("Welcome"+patientName.get(j)+"to book your appointment chose your doctor..");
			
			for(int i=0;i<=doctorName.size()-1;i++)
			{
				System.out.println((i+1) +"." +doctorName.get(i));
			}
			choice=sc.nextByte();
			doctorID.add(choice);
			
			while (flag)
			{
				  Thread.sleep(1000);
				   new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
					System.out.println("  -------------------------------- ");
					System.out.println(" |                                | ");
					System.out.println(" |      Book   Appointment        | ");
					System.out.println(" |                                | ");
					System.out.println("  -------------------------------- ");
					
					if(choice<=doctorName.size() && choice>0)
					{
						System.out.println("Name"+doctorName.get(choice-1)+ "Age" +doctorAge.get(choice-1));
						System.out.println("Enter your Name");
						sc.nextLine();
						patientNameBooking.add(sc.nextLine());
						System.out.println("Enter your age");
						patientAgeBooking.add(sc.nextInt());
						System.out.println("Enter your Gender");
						patientGenderBooking.add(sc.next());
						System.out.println("Booking Successful");
						Thread.sleep(1000);
						flag=false;
						break;
						
					}
					else
					{
						System.out.println("Enter correct option");
						flag=true;
						Thread.sleep(1000);
					}
			}
	   }
	   else
	   {
		   System.out.println("Login  UnSuccessful");
		   Thread.sleep(1000);
		   flag=false;
	   }
		
	}


	private void doctor() throws Exception {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner (System.in);
		int choice;
		
		boolean flag=true;
		while (flag) {
			new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
			System.out.println("  -------------------------------- ");
			System.out.println(" |                                | ");
			System.out.println(" |     Welcome to Doctor  page    | ");
			System.out.println(" |                                | ");
			System.out.println("  -------------------------------- ");
			System.out.println("");
			System.out.println("1.login");
			System.out.println("2.Registration");
		    choice=sc.nextInt();
			switch(choice) { 
			case 1:
				if (doctorMobileNumber.isEmpty())
				{
					System.out.println("Register First--!");
					flag=false;
					Thread.sleep(500);
					break;
				}
				else
				{
					doctorLogin();
					flag=false;
				}
				break;
			case 2:
				doctorRegistration();
				flag=false;
				break;
				default:
					System.out.println(" Entered Wrong Choice");
					flag=true;
					
			
			}
		}
		
	}

			private void doctorRegistration() throws Exception{
		// TODO Auto-generated method stub
				Scanner sc =new Scanner (System.in);
				int i=0;
				long mobileNumber;
				boolean flag=true ,flag1=true;

				new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
				
				
				System.out.println("");
				System.out.println("Welcome to doctor registration page");
				System.out.println("");
				
				System.out.println("Please enter your name");
				doctorName.add(sc.nextLine());
				
				System.out.println("Please enter your mobile number");
				mobileNumber=(sc.nextLong());
				
				long mno;
				
				if(doctorMobileNumber.add(mobileNumber))
				{
					doctorMobileNumber.add(mobileNumber);
					System.out.println("Enter password");
					doctorPassword.add(sc.next());
					System.out.println("Registration is successful");
					Thread.sleep(900);
					flag1=false;
				}
				else
				{
					for(i=0;i<=doctorMobileNumber.size()-1;i++)
					{
						mno=doctorMobileNumber.get(i);
						if(mno== mobileNumber)
						{
							flag1=false;
							break;
						}
					}
					if(flag1==true)
					{
						doctorMobileNumber.add(mobileNumber);
						System.out.println("Enter age");
						doctorAge.add(sc.nextInt());
						System.out.println("Enter city");
						doctorCity.add(sc.next());
						System.out.println("Enter password");
						doctorPassword.add(sc.next());
						System.out.println("Registration is successful");
						System.out.println("Details Name:"+ doctorName+"Number:"+doctorMobileNumber);
						Thread.sleep(900);
					}
					else
					{
						System.out.println("Same mobile number is not alowed");
						int index=doctorName.size()-1;
						doctorName.remove(index);
						Thread.sleep(500);
					}
				}
	}


			private void doctorLogin() throws Exception {
		// TODO Auto-generated method stub
				Scanner sc=new Scanner(System.in);
				long mobileNumber;
				boolean flag=false ,flag11=true;
		        int i=0;
		        byte choice;
				new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
				
				
				System.out.println("");
				System.out.println("Welcome to doctor login page");
				System.out.println("");
				
				System.out.println("Please enter your username(mobilenumber)");
				mobileNumber=(sc.nextLong());
				
				System.out.println("Please enter your password");
				String pasword=(sc.next());
				
				for(i=0;i<=doctorMobileNumber.size()-1;i++)
				{
					if((doctorMobileNumber.get(i)).equals(mobileNumber) && (doctorPassword.get(i)).equals(pasword))
					{
						flag=true;
						break;	
					}
					
				}
				if(flag==true)
				{
					while(flag11)
					{
						new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
						System.out.println("  -----------------------------------------");
						System.out.println(" | Welcome  doctor  |"+doctorName.get(i)+" |");
						System.out.println("  -----------------------------------------");	
						System.out.println("1: Appointment");
						System.out.println("2: Logout");
						choice=sc.nextByte();
						byte j=0;
						switch(choice)
						{
						case 1:
							if((doctorID.isEmpty()!=true))
							{
								while(j<=doctorID.size()-1)
								{
									if((i+1)== doctorID.get(j))
									{
										System.out.println("patient name:"+patientNameBooking.get(j));
										j++;
										
									}
								}
									Thread.sleep(4000);
							}
							else
							{
								System.out.println("No Appointments");
								Thread.sleep(3000);
								flag11=true;
							}
							break;
						case 2:
							flag11=false;
							break;
						}	
					}
				}
				else
				{
					System.out.println("Login unsuccessful");
					Thread.sleep(1000);
				}
	}

			ArrayList<String> doctorName=new ArrayList<String>();
			ArrayList<String> doctorQualification=new ArrayList<String>();
			ArrayList<String> doctorGender=new ArrayList<String>();
			ArrayList<String> doctorPassword=new ArrayList<String>();
			ArrayList<Integer> doctorAge=new ArrayList<Integer>();
			ArrayList<Long> doctorMobileNumber=new ArrayList<Long>();
			ArrayList<String> doctorCity=new ArrayList<String>();
			
			ArrayList<Integer> patientAge=new ArrayList<Integer>();
			ArrayList<String> patientName=new ArrayList<String>();
			ArrayList<String> patientGender=new ArrayList<String>();
			ArrayList<String> patientPassword=new ArrayList<String>();
			ArrayList<String> patientConfirmPassword=new ArrayList<String>();
			ArrayList<Long> patientMobileNumber=new ArrayList<Long>();
			
			ArrayList<Integer> patientAgeBooking=new ArrayList<Integer>();
			ArrayList<String> patientNameBooking=new ArrayList<String>();
			ArrayList<String> patientGenderBooking=new ArrayList<String>();
			ArrayList<Byte> doctorID=new ArrayList<Byte>();
	 
	private void dataAdd() {
		// TODO Auto-generated method stub
		doctorName.add("Faheem Mir");
		doctorName.add("Urooj Lone");
		doctorName.add("Danish Meer");
		doctorName.add("suhaib Azad");
		doctorName.add("Zuha Jan");
		doctorName.add("Faixan Manzoor");
		doctorName.add("Atif Lone");
		
		doctorQualification.add("MBBS");
		doctorQualification.add("Er,MBBS");
		doctorQualification.add("MBBS,MD");
		doctorQualification.add("MBBS,MD");
		doctorQualification.add("BAMS");
		doctorQualification.add("MBBS,MD,Surgeon");
		doctorQualification.add("BAMS");
		
		doctorGender.add("M");
		doctorGender.add("M");
		doctorGender.add("M");
		doctorGender.add("M");
		doctorGender.add("F");
		doctorGender.add("M");
		doctorGender.add("M");
		
		doctorPassword.add("Faheem@111");
		doctorPassword.add("Urooj@111");
		doctorPassword.add("Danish@111");
		doctorPassword.add("Suhai@111");
		doctorPassword.add("Zuha@111");
		doctorPassword.add("Faixan@111");
		doctorPassword.add("Atif@111");
		
		doctorAge.add(25);
		doctorAge.add(24);
		doctorAge.add(29);
		doctorAge.add(28);
		doctorAge.add(26);
		doctorAge.add(30);
		doctorAge.add(23);
		
		doctorMobileNumber.add(123l);
		doctorMobileNumber.add(123l);
		doctorMobileNumber.add(123l);
		doctorMobileNumber.add(123l);
		doctorMobileNumber.add(123l);
		doctorMobileNumber.add(123l);
		doctorMobileNumber.add(123l);
		
		doctorCity.add("Kulgam");
		doctorCity.add("Shopain");
		doctorCity.add("Islamabad");
		doctorCity.add("Sapore");
		doctorCity.add("Tral");
		doctorCity.add("Pulwama");
		doctorCity.add("Budgam");
	}
}

