module DoctorAppointmentSystem {
	requires java.sql;
}